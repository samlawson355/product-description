// FOR DEPLOYMENT USE
// let host = "production-desc-db.cjnwcbynmw3t.us-east-2.rds.amazonaws.com";
// let user = "admin";
// let password = "Passw0rd775511!";
// let database = "amazonProductDescriptions";

// FOR LOCAL USE
let host = "localhost";
let user = "root";
let password = "password";
let database = "amazonProductDescriptions";

module.exports = { host, user, password, database };
